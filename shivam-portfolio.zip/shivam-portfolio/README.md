# 🚀 Shivam Chauhan — Portfolio Website
Full-stack portfolio with PHP backend + MySQL database.

---

## 📁 File Structure

```
shivam-portfolio/
├── index.html          ← Main portfolio page
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← All JavaScript (particles, API calls, form, etc.)
├── php/
│   ├── db.php          ← Database config (edit credentials here)
│   ├── api.php         ← GET endpoint — returns projects/skills/experience
│   ├── contact.php     ← POST endpoint — saves contact form to DB
│   └── track.php       ← Page view tracker
└── database.sql        ← Run this first to set up all tables + seed data
```

---

## ⚙️ Setup Instructions

### 1. Database Setup
Open **phpMyAdmin** (or MySQL CLI) and run:
```sql
SOURCE /path/to/database.sql;
```
This creates the `shivam_portfolio` database with all tables and seed data.

### 2. Configure DB credentials
Edit `php/db.php`:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'your_username');   // ← change this
define('DB_PASS', 'your_password');   // ← change this
define('DB_NAME', 'shivam_portfolio');
```

### 3. Deploy to Web Server
Upload the whole folder to your web server (XAMPP, WAMP, cPanel, etc.)
- XAMPP: Place in `htdocs/shivam-portfolio/`
- Visit: `http://localhost/shivam-portfolio/`

### 4. For Production
- Point your domain to the `index.html` entry point
- Ensure PHP 7.4+ and MySQL 5.7+ are available
- Enable HTTPS for the contact form

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `projects` | Portfolio projects (title, desc, tech stack, links) |
| `skills` | Technical skills with proficiency levels |
| `experience` | Internship/work experience |
| `messages` | Contact form submissions (with rate limiting) |
| `page_views` | Analytics — visitor tracking |

---

## ✨ Features

- **Custom cursor** with hover effects
- **Animated particle canvas** in hero
- **Typewriter** effect
- **Scroll reveal** animations
- **Skill tab filtering** (Frontend/Backend/Language/Tools)
- **Project modal** with full description
- **Contact form** with real-time validation → saves to MySQL
- **Rate limiting** — max 5 messages/IP/hour
- **Responsive** — mobile-first
- **Static fallback** — works even without PHP (shows demo data)

---

## 📬 Viewing Contact Messages

```sql
USE shivam_portfolio;
SELECT name, email, subject, sent_at FROM messages ORDER BY sent_at DESC;
```

---

Built with ❤️ for Shivam Chauhan · Lucknow, India
